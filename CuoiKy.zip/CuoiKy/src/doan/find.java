
package doan;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Button;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.print.Book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;

public class find extends JFrame {
	private JPanel contentPane;
	private JTable table;
	private JTextField txtFind;
	private JTextField txtfind;
	private JTextField txtfindtime;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					find frame = new find();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public find() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 734, 484);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Th\u00F4ng tin nh\u00E2n s\u1EF1 ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(274, 10, 211, 45);
		contentPane.add(lblNewLabel);
		
		Panel panel = new Panel();
		panel.setBounds(55, 61, 659, 200);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Find by ID , Salary ");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(0, 17, 184, 52);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Find");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hi\u0300nh a\u0309nh\\icons8-search-16.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				person ps = new person();
				ps.setID(Integer.parseInt(txtFind.getText()));
				ps.setSalary(Integer.parseInt(txtFind.getText()));
			    DisplayonJtable(Database.findByAll(ps));
			}
		});
		btnNewButton.setBounds(482, 24, 148, 34);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panel.add(btnNewButton);
		txtFind = new JTextField();
		txtFind.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtFind.setBounds(217, 27, 255, 34);
		panel.add(txtFind);
		txtFind.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Find by Name,Position,Job");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(0, 68, 184, 46);
		panel.add(lblNewLabel_1_1);
		
		txtfind = new JTextField();
		txtfind.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtfind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		txtfind.setColumns(10);
		txtfind.setBounds(217, 75, 255, 34);
		panel.add(txtfind);
		
		JButton btnNewButton_1 = new JButton("Find");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hi\u0300nh a\u0309nh\\icons8-search-16.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				person ps = new person();
				ps.setName(txtfind.getText());
				ps.setPosition(txtfind.getText());
				ps.setJob(txtfind.getText());
				DisplayonJtable(Database.findByAll1(ps));
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.setBounds(482, 75, 148, 34);
		panel.add(btnNewButton_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Find by Timework : ");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(0, 112, 148, 46);
		panel.add(lblNewLabel_1_1_1);
		
		txtfindtime = new JTextField();
		txtfindtime.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtfindtime.setColumns(10);
		txtfindtime.setBounds(217, 119, 255, 34);
		panel.add(txtfindtime);
		
		JButton btnNewButton_1_1 = new JButton("Find");
		btnNewButton_1_1.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hi\u0300nh a\u0309nh\\icons8-search-16.png"));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				person ps = new person();
				ps.setTimework(txtfindtime.getText());
				DisplayonJtable(Database.findByAll2(ps));
			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1_1.setBounds(482, 119, 148, 34);
		panel.add(btnNewButton_1_1);
		
		JButton btnBack = new JButton("Back ");
		btnBack.setIcon(new ImageIcon("C:\\Users\\hoang\\Downloads\\icons8-back-24.png"));
		btnBack.setBounds(348, 156, 123, 34);
		panel.add(btnBack);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		JButton btnClear = new JButton("Clear");
		btnClear.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hi\u0300nh a\u0309nh\\icons8-refresh-16.png"));
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtfind.setText("");
				txtFind.setText("");
				txtfindtime.setText("");
			}
		});
		btnClear.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnClear.setBounds(116, 156, 123, 34);
		panel.add(btnClear);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(65, 267, 607, 166);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"ID", "Name", "Age", "Gender", "Job", "Position", "Salary", "Timework"
			}
		));
		DisplayonJtable(ShowPerson());
	}
	static String url="jdbc:mysql://localhost:3306/personmn";
	static String user="root";
	static String password="";
	public static Connection getConnection() { //connect
	Connection connection=null;
	try {
		connection = DriverManager.getConnection(url,user,password);
	} catch (Exception ex) {
		ex.printStackTrace();
				}
		return connection;
			}
	public static List<person>ShowPerson(){
		List<person>PersonList=new ArrayList<>();
		String query="select*from person";
		try {
			Connection connection =getConnection();
			Statement stmt=connection.createStatement();
			ResultSet rs= stmt.executeQuery(query);  
			while(rs.next()) {   
				person ps=new person(rs.getInt("id"),rs.getString("name"),rs.getInt("age"),
						             rs.getInt("gender"),rs.getString("job"),rs.getString("position"),rs.getInt("salary"),rs.getString("timework"));
				PersonList.add(ps);  
			}
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		return PersonList; 
	}
	public void DisplayonJtable(List<person>personl) { 
		List<person>PersonList=new ArrayList<>();
		PersonList=personl;
		DefaultTableModel tableModel;
	    table.getModel();
	    tableModel=(DefaultTableModel)table.getModel();
	    tableModel.setRowCount(0);
	    PersonList.forEach((person) -> { 
	    	String gender;
	    	if(person.getGender()==0)gender="Male";
	    	else {gender="Female";}
	    	tableModel.addRow(new Object [] { //��a v�o model
	    		person.getID(),person.getName(),person.getAge(),
	    		gender,person.getJob(),person.getPosition(),person.getSalary(),person.getTimework()
	    });
	    });
	} //
}