package doan;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JTabbedPane;
import java.awt.Panel;
public class login extends JFrame {

	private JPanel contentPane;
	private JTextField txtTK;
	private JPasswordField txtMK;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public login() {
		setTitle("login and sign up ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 388);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("New label");
		label.setBounds(106, 10, 3, 5);
		contentPane.add(label);
		
		JLabel lblNewLabel = new JLabel("Username :");
		lblNewLabel.setBounds(10, 81, 105, 53);
		contentPane.add(lblNewLabel);
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBackground(Color.YELLOW);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblNewLabel_1 = new JLabel("Password :");
		lblNewLabel_1.setBounds(10, 158, 105, 59);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 19));
		
		txtTK = new JTextField();
		txtTK.setBounds(144, 89, 301, 37);
		contentPane.add(txtTK);
		txtTK.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtTK.setColumns(10);
		
		txtMK = new JPasswordField();
		txtMK.setBounds(144, 169, 301, 37);
		contentPane.add(txtMK);
		txtMK.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBounds(10, 266, 167, 65);
		contentPane.add(btnNewButton);
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hi�nh a�nh\\login_64px.png"));
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent evt) {
				Database cn= new Database();
				Connection conn=null;
				try {
				 if(txtMK.getText().equals("")||txtTK.getText().equals("")) {
				    JOptionPane.showMessageDialog(null,"Please fill in username and password !");
							}
					  try {
							conn = cn.getConnection();
							String sql = "select*from dangnhap Where TenDangNhap=? and MatKhau=?";
						    PreparedStatement pst = conn.prepareCall(sql);
						    pst.setString(1, txtTK.getText());
						    pst.setString(2, txtMK.getText());
							ResultSet rs = pst.executeQuery();
							  if(rs.next())
						     {
						    jframeperson j = new  jframeperson();
						    j.show();
						    this.hide();
						    JOptionPane.showMessageDialog(null, "You are logged in as a manager !");
						    dispose();
						     }
					  else {
					    JOptionPane.showMessageDialog(null, "Username or password incorrect !");
					    }
							} catch(Exception ex) {
							}
			    	
				   } 
					catch (Exception e) {
					 JOptionPane.showMessageDialog(null,e.toString());
                     e.printStackTrace();
					}
			}
	
			private void hide() {
				// TODO Auto-generated method stub
			}		
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.setBounds(187, 266, 181, 65);
		contentPane.add(btnRefresh);
		btnRefresh.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hi�nh a�nh\\refresh_64px.png"));
		btnRefresh.setForeground(Color.BLUE);
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtMK.setText("");
				txtTK.setText("");
			}
		});
		btnRefresh.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblNewLabel_2 = new JLabel("Login to system");
		lblNewLabel_2.setBounds(194, 10, 250, 53);
		contentPane.add(lblNewLabel_2);
		lblNewLabel_2.setForeground(Color.BLUE);
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(378, 266, 181, 65);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setForeground(Color.BLUE);
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(btnExit);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hi�nh a�nh\\loading-9.gif"));
		setLocationRelativeTo (null);
		lblNewLabel_3.setBounds(0, 0, 586, 341);
		contentPane.add(lblNewLabel_3);
	}
}