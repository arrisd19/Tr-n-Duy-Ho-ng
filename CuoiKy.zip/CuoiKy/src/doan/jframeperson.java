package doan;
import java.awt.EventQueue;
	import javax.swing.JFrame;
	import javax.swing.JPanel;
	import javax.swing.border.EmptyBorder;
	import javax.swing.JLabel;
	import javax.swing.JOptionPane;
	import java.awt.Font;
	import java.util.ArrayList;
	import java.util.List;
	import javax.swing.JTextField;
	import javax.swing.JComboBox;
	import javax.swing.DefaultComboBoxModel;
	import javax.swing.JButton;
	import javax.swing.JScrollPane;
	import javax.swing.JTable;
	import javax.swing.table.DefaultTableModel;
	import java.awt.event.ActionListener;
	import java.awt.event.ActionEvent;
	import java.awt.Color;
	import javax.swing.ImageIcon;
	import java.awt.Panel;
	import javax.swing.JTabbedPane;
public class jframeperson extends JFrame{
	
		private JPanel contentPane;
		private JTextField txtName;
		private JTextField txtAge;
		private JTextField txtPosition;
		private static JTable table1;
		private JTextField txtSalary;
		private JTextField txtID;
	
		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						jframeperson frame = new jframeperson();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
	
		/**
		 * Create the frame.
		 */
		public jframeperson() {
			setTitle("Person Managerment");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 959, 744);
			contentPane = new JPanel();
			contentPane.setBackground(Color.LIGHT_GRAY);
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			
			JLabel lblNewLabel = new JLabel("Person Managerment");
			lblNewLabel.setBounds(18, 0, 336, 68);
			lblNewLabel.setForeground(Color.BLUE);
			lblNewLabel.setFont(new Font("Calibri Light", Font.BOLD, 35));
			contentPane.add(lblNewLabel);
			
			JLabel lblNewLabel_2 = new JLabel("New label");
			lblNewLabel_2.setBounds(105, 0, -292, 393);
			contentPane.add(lblNewLabel_2);
			
			JLabel lblNewLabel_3 = new JLabel("");
			lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\HiÌnh aÒnh\\people.png"));
			lblNewLabel_3.setBounds(8, 0, 58, 51);
			contentPane.add(lblNewLabel_3);
			
			Panel panel = new Panel();
			panel.setBounds(8, 0, 15, -1);
			contentPane.add(panel);
			
			JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane.setBounds(18, 61, 917, 597);
			contentPane.add(tabbedPane);
			
			Panel panel_2 = new Panel();
			panel_2.setBackground(Color.GRAY);
			tabbedPane.addTab("Home Page ", null, panel_2, null);
			panel_2.setLayout(null);
			
			JLabel lblNewLabel_4 = new JLabel("H\u1EC7 th\u1ED1ng qu\u1EA3n l\u00FD nh\u00E2n s\u1EF1 ");
			lblNewLabel_4.setForeground(Color.YELLOW);
			lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 40));
			lblNewLabel_4.setBounds(239, 10, 474, 72);
			panel_2.add(lblNewLabel_4);
			
			JLabel lblNewLabel_5 = new JLabel("");
			lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hình ảnh\\nhansu-15272952345711312615035.png"));
			lblNewLabel_5.setBounds(151, 92, 660, 384);
			panel_2.add(lblNewLabel_5);
			
			Panel panel_4 = new Panel();
			tabbedPane.addTab("Add Person", null, panel_4, null);
			panel_4.setLayout(null);
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(328, 46, 574, 197);
			panel_4.add(scrollPane);
			table1 = new JTable();
			scrollPane.setViewportView(table1);
			table1.setForeground(Color.BLUE);
			table1.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null, null},
				},
				new String[] {
					"ID", "Name", "Age", "Gender", "job", "Position", "Salary", "Timework"
				}
			));
			table1.getColumnModel().getColumn(0).setPreferredWidth(30);
			table1.getColumnModel().getColumn(0).setMinWidth(30);
			table1.getColumnModel().getColumn(1).setPreferredWidth(111);
			table1.getColumnModel().getColumn(1).setMinWidth(100);
			table1.getColumnModel().getColumn(2).setPreferredWidth(30);
			table1.getColumnModel().getColumn(2).setMinWidth(30);
			table1.getColumnModel().getColumn(3).setPreferredWidth(60);
			table1.getColumnModel().getColumn(3).setMinWidth(40);
			table1.getColumnModel().getColumn(4).setPreferredWidth(100);
			table1.getColumnModel().getColumn(4).setMinWidth(100);
			table1.getColumnModel().getColumn(5).setMinWidth(50);
			table1.getColumnModel().getColumn(6).setPreferredWidth(81);
			table1.setFont(new Font("Tahoma", Font.PLAIN, 14));
			Panel panel_1 = new Panel();
			panel_1.setBounds(0, 10, 322, 550);
			panel_4.add(panel_1);
			panel_1.setLayout(null);
			
			JLabel lblNewLabel_1 = new JLabel("Name :");
			lblNewLabel_1.setBounds(10, 93, 71, 37);
			panel_1.add(lblNewLabel_1);
			lblNewLabel_1.setForeground(Color.DARK_GRAY);
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JLabel lblNewLabel_1_5 = new JLabel("ID :");
			lblNewLabel_1_5.setBounds(10, 46, 71, 37);
			panel_1.add(lblNewLabel_1_5);
			lblNewLabel_1_5.setForeground(Color.DARK_GRAY);
			lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JLabel lblNewLabel_1_1 = new JLabel("Age :");
			lblNewLabel_1_1.setBounds(10, 140, 71, 37);
			panel_1.add(lblNewLabel_1_1);
			lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JLabel lblNewLabel_1_2 = new JLabel("Gender :");
			lblNewLabel_1_2.setBounds(10, 187, 71, 43);
			panel_1.add(lblNewLabel_1_2);
			lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JLabel lblNewLabel_1_3 = new JLabel("Job : ");
			lblNewLabel_1_3.setBounds(10, 246, 71, 36);
			panel_1.add(lblNewLabel_1_3);
			lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JLabel lblNewLabel_1_4 = new JLabel("Position :");
			lblNewLabel_1_4.setBounds(10, 310, 71, 37);
			panel_1.add(lblNewLabel_1_4);
			lblNewLabel_1_4.setForeground(Color.BLACK);
			lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			txtID = new JTextField();
			txtID.setBounds(109, 47, 200, 36);
			panel_1.add(txtID);
			txtID.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txtID.setColumns(10);
			
			txtName = new JTextField();
			txtName.setBounds(109, 94, 200, 36);
			panel_1.add(txtName);
			txtName.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txtName.setColumns(10);
			
			txtAge = new JTextField();
			txtAge.setBounds(109, 141, 200, 36);
			panel_1.add(txtAge);
			txtAge.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txtAge.setColumns(10);
			JComboBox<Object> cbGender = new JComboBox<Object>();
			cbGender.setBounds(109, 190, 109, 36);
			panel_1.add(cbGender);
			cbGender.setForeground(Color.BLUE);
			cbGender.setFont(new Font("Tahoma", Font.BOLD, 14));
			cbGender.setModel(new DefaultComboBoxModel<Object>(new String[] {"Male", "Female"}));
			
			txtPosition = new JTextField();
			txtPosition.setBounds(109, 311, 200, 36);
			panel_1.add(txtPosition);
			txtPosition.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txtPosition.setColumns(10);
			JLabel lblNewLabel_1_4_1 = new JLabel("Salary :");
			lblNewLabel_1_4_1.setBounds(10, 426, 71, 37);
			panel_1.add(lblNewLabel_1_4_1);
			lblNewLabel_1_4_1.setFont(new Font("Tahoma", Font.BOLD, 14));
			txtSalary = new JTextField();
			txtSalary.setBounds(109, 427, 200, 36);
			panel_1.add(txtSalary);
			txtSalary.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txtSalary.setColumns(10);
			
			JComboBox<Object> ComboxCV = new JComboBox<Object>();
			ComboxCV.setModel(new DefaultComboBoxModel(new String[] {"Nhân Sự ", "Tổ chức, quản lý sự kiện", "Quan hệ lao động xã hội", "Phân tích công việc và lương thưởng"}));
			ComboxCV.setForeground(Color.BLUE);
			ComboxCV.setFont(new Font("Tahoma", Font.BOLD, 14));
			ComboxCV.setBounds(109, 246, 200, 36);
			panel_1.add(ComboxCV);
			
			JLabel lblNewLabel_1_4_2 = new JLabel("Timework : ");
			lblNewLabel_1_4_2.setForeground(Color.BLACK);
			lblNewLabel_1_4_2.setFont(new Font("Tahoma", Font.BOLD, 14));
			lblNewLabel_1_4_2.setBounds(10, 367, 92, 37);
			panel_1.add(lblNewLabel_1_4_2);
			
			JComboBox<Object> cbTimework = new JComboBox<Object>();
			cbTimework.setModel(new DefaultComboBoxModel(new String[] {"Morning ", "Afternoon", "Full time"}));
			cbTimework.setForeground(Color.BLUE);
			cbTimework.setFont(new Font("Tahoma", Font.BOLD, 14));
			cbTimework.setBounds(109, 367, 131, 36);
			panel_1.add(cbTimework);
			
			JButton btnFind = new JButton("Find");
			btnFind.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hình ảnh\\icons8-search-16.png"));
			btnFind.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					find f=new find();
					f.setVisible(true);
					
				}
			});
			btnFind.setForeground(Color.BLUE);
			btnFind.setFont(new Font("Tahoma", Font.BOLD, 14));
			btnFind.setBounds(375, 368, 132, 37);
			panel_4.add(btnFind);
			
			JButton btnDelete = new JButton("Delete");
			btnDelete.setBounds(711, 272, 132, 37);
			panel_4.add(btnDelete);
			btnDelete.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hình ảnh\\icons8-trash-can-30.png"));
			btnDelete.setForeground(Color.BLUE);
			btnDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					 int click=JOptionPane.showConfirmDialog(null, "Do you want to delete ? ");
						if(click==JOptionPane.YES_OPTION) {
						JOptionPane.showMessageDialog(null, "Delete Success!");
					 	}
						if(click==JOptionPane.NO_OPTION) {
					   return;
		             	}
						if(click==JOptionPane.CANCEL_OPTION) {
			           return;
						}
	             	person ps=new person();
	             	ps.setID(Integer.parseInt(txtID.getText()));
				  Database.delete(ps);
				DisplayonJtable(Database.ShowPerson());
				}
			});
			btnDelete.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JButton btnNewButton = new JButton("Save");
			btnNewButton.setBounds(375, 272, 132, 37);
			panel_4.add(btnNewButton);
			btnNewButton.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hình ảnh\\icons8-save-32.png"));
			btnNewButton.setForeground(Color.BLUE);
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
	           if(txtID.getText().equals("")||txtName.getText().equals("")||txtAge.getText().equals("")||txtPosition.getText().equals("")||txtSalary.getText().equals("")) {
	        	 JOptionPane.showMessageDialog(null,"Please fill in all the information");
					}
				} catch(Exception ex) {	
				}
			    	person ps=new person();
				    ps.setID(Integer.parseInt(txtID.getText()));
					ps.setName(txtName.getText());
					ps.setAge(Integer.parseInt(txtAge.getText()));
					ps.setGender(cbGender.getSelectedIndex());
					ps.setJob(ComboxCV.getSelectedItem().toString());
					ps.setPosition(txtPosition.getText());
					ps.setSalary(Integer.parseInt(txtSalary.getText()));
					ps.setTimework(cbTimework.getSelectedItem().toString());
					Database.Save(ps);
				    JOptionPane.showMessageDialog(null, "Save Success!");
				  	DisplayonJtable(Database.ShowPerson());
				}	
			});
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JButton btnUpdate = new JButton("Update");
			btnUpdate.setBounds(547, 272, 132, 37);
			panel_4.add(btnUpdate);
			btnUpdate.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hình ảnh\\icons8-update-32 (1).png"));
			btnUpdate.setForeground(Color.BLUE);
			btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					 int click=JOptionPane.showConfirmDialog(null, "Do you want to update ? ");
						if(click==JOptionPane.YES_OPTION) {
						JOptionPane.showMessageDialog(null, "Update Success! ");
						person ps=new person();
						ps.setID(Integer.parseInt(txtID.getText()));
						ps.setName(txtName.getText());
						ps.setAge(Integer.parseInt(txtAge.getText()));
						ps.setJob(ComboxCV.getSelectedItem().toString());
						ps.setPosition(txtPosition.getText());
						ps.setGender(cbGender.getSelectedIndex());
						ps.setSalary(Integer.parseInt(txtSalary.getText()));
						ps.setTimework(cbTimework.getSelectedItem().toString());
						Database.Update(ps);
						DisplayonJtable(Database.ShowPerson());
						}
						if(click==JOptionPane.NO_OPTION) {
	        	}
						if(click==JOptionPane.CANCEL_OPTION) {
			       	}
				}
			});
			btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 14));
			JButton btnRefresh = new JButton("Clear");
			btnRefresh.setBounds(547, 368, 132, 37);
			panel_4.add(btnRefresh);
			btnRefresh.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hình ảnh\\icons8-refresh-16.png"));
			btnRefresh.setForeground(Color.BLUE);
			btnRefresh.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					txtID.setText("");
					txtName.setText("");
					txtAge.setText("");
					txtPosition.setText("");
					txtSalary.setText("");
					}
			});
			btnRefresh.setFont(new Font("Tahoma", Font.BOLD, 14));
			
			JButton btnExit = new JButton("Exit");
			btnExit.setIcon(new ImageIcon("C:\\Users\\hoang\\Downloads\\icons8-exit-60.png"));
			btnExit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btnExit.setForeground(Color.BLUE);
			btnExit.setFont(new Font("Tahoma", Font.BOLD, 14));
			btnExit.setBounds(711, 368, 132, 37);
			panel_4.add(btnExit);
			
			JLabel lblNewLabel_6 = new JLabel("");
			lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\hoang\\OneDrive\\Hình ảnh\\background-powerpoint-kinh-te-3 (1).jpg"));
			lblNewLabel_6.setBounds(0, 0, 902, 570);
			panel_4.add(lblNewLabel_6);
			DisplayonJtable(Database.ShowPerson());
		}
		public void DisplayonJtable(List<person>personal) { 
			List<person>PersonList=new ArrayList<>();
			PersonList=personal;
			DefaultTableModel tableModel;
		    table1.getModel();
		    tableModel=(DefaultTableModel)table1.getModel();
		    tableModel.setRowCount(0);
		    PersonList.forEach((person) -> { 
		    	String gender;
		    	if(person.getGender()==0)gender="Male";
		    	else {gender="Female";}
		    	tableModel.addRow(new Object [] { //đưa vào model
		    		person.getID(),person.getName(),person.getAge(),
		    		gender,person.getJob(),person.getPosition(),person.getSalary(),person.getTimework()
		    });
		    });
		}
	}