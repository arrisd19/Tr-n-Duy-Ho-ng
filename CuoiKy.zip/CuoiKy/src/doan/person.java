package doan;
public class person {
private int id; 
private String name; 
private int age,gender;	
private String job; 
private String position;
private int salary ;
private String timework ; 
public person(int id,String name,int age,int gender,String job,String position,int salary,String timework) {
	this.id=id;
	this.name=name;
	this.age=age;
	this.gender=gender;
	this.job=job;
	this.position=position;
	this.salary=salary;
	this.timework=timework ; 
}

public person() {
	// TODO Auto-generated constructor stub
}
public void setName(String name) {
	this.name=name;
}
public void setID(int id) {
	 this.id=id;
}
public void setTimework(String timework) {
	 this.timework=timework;
}
public void setAge(int age) {
	if(age>=0 && age<=100 ) {
	this.age=age ; 
	}
}
public void setSalary(int salary) {
	if(salary>=0 ) {
	this.salary=salary;
	}
}
public void setGender(int gender) {
	this.gender=gender;
}
public void setJob(String job) {
	this.job=job;
}
public void setPosition(String position) {
	this.position=position;
}
public String getName() {
	return name;
}
public int getAge() {
	return age;	
} 
public int getGender() {
	return gender;
}
public String getJob() {
	return job;
}
public String getTimework() {
	return timework;
}
public String getPosition() {
	return position;
}
public int getID() {
	 return id;
}
public int getSalary() {
	return salary;
}
}