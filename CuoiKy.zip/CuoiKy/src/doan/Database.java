package doan;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.List;
public class Database {
static String url="jdbc:mysql://localhost:3306/personmn";
static String user="root";
static String password="";
public static Connection getConnection() { //connect
Connection connection=null;
       try {
	connection = DriverManager.getConnection(url,user,password);
        }     catch (Exception ex) {
	ex.printStackTrace();
			}
	return connection;
		}
public static List<person>ShowPerson(){
			List<person>PersonList=new ArrayList<>();
			String query="select*from person";
			try {
				Connection connection =getConnection();
				Statement stmt=connection.createStatement();
				ResultSet rs= stmt.executeQuery(query);  
				while(rs.next()) {   
					person ps=new person(rs.getInt("id"),rs.getString("name"),rs.getInt("age"),
							             rs.getInt("gender"),rs.getString("job"),rs.getString("position"),rs.getInt("salary"),rs.getString("timework"));
					PersonList.add(ps);  
				}
			} catch (Exception e) {
				System.out.println(e);
				// TODO: handle exception
			}
			return PersonList; 
		}
     public static void Save(person ps) {
			String query="insert into person(id,name,age,gender,job,position,salary,timework) values(?,?,?,?,?,?,?,?)";
			try {
				Connection connection = getConnection() ; 
				PreparedStatement pst=connection.prepareStatement(query); 
				pst.setInt(1, ps.getID());
				pst.setString(2, ps.getName());
				pst.setInt(3, ps.getAge());
				pst.setInt(4, ps.getGender());
				pst.setString(5, ps.getJob());
				pst.setString(6, ps.getPosition());
				pst.setInt(7, ps.getSalary());
				pst.setString(8, ps.getTimework());
				pst.execute(); 
		} catch (Exception e) {
				// TODO: handle exception
			}
		}
		public static void delete(person ps) {
			String query="delete from person where id='"+ps.getID()+"'";
			try {
				Connection connection =getConnection();
				PreparedStatement pstmt=connection.prepareStatement(query);
				pstmt.executeUpdate();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		public static void Update(person ps) {
String query="Update person set id=?,name=?,age=?,gender=?,job=?,position=?,salary=?,timework=? where id='"+ps.getID()+"'";
			try {
				Connection connection=getConnection();
				PreparedStatement pst=connection.prepareStatement(query);
				pst.setInt(1, ps.getID());
				pst.setString(2, ps.getName());
				pst.setInt(3, ps.getAge());
				pst.setInt(4, ps.getGender());
				pst.setString(5, ps.getJob());
				pst.setString(6, ps.getPosition());
				pst.setInt(7, ps.getSalary());
				pst.setString(8, ps.getTimework());
				pst.executeUpdate();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		public static List<person>findByAll(person p) {
			List<person>personl= new ArrayList<>();
			String query="select*from person where id='"+p.getID()+"' or salary='"+p.getSalary()+"'";
				try {
						Connection connection =getConnection();
						Statement stmt= connection.createStatement();
						ResultSet rs=stmt.executeQuery(query);
						while(rs.next()) {
							person ps=new person(rs.getInt("id"),rs.getString("name"),rs.getInt("age"),
									rs.getInt("gender"),rs.getString("job"),rs.getString("position"),rs.getInt("salary"),rs.getString("timework"));
							personl.add(ps);	
						}
					} catch (Exception e) {
						// TODO: handle exception
					}
					return personl;
				}
		public static List<person>findByAll1(person p) {
			List<person>personl= new ArrayList<>();
			String query="select*from person where name= '"+p.getName()+"'or position= '"+p.getPosition()+"' or job='"+p.getJob()+"'" ;
				try {
						Connection connection =getConnection();
						Statement stmt= connection.createStatement();
						ResultSet rs=stmt.executeQuery(query);
						while(rs.next()) {
							person ps=new person(rs.getInt("id"),rs.getString("name"),rs.getInt("age"),
									rs.getInt("gender"),rs.getString("job"),rs.getString("position"),rs.getInt("salary"),rs.getString("timework"));
							personl.add(ps);
						}
					} catch (Exception e) {
						// TODO: handle exception
					}
					return personl;
				}
		public static List<person>findByAll2(person p) {
			List<person>personl= new ArrayList<>();
			String query="select*from person where timework='"+p.getTimework()+"'" ;
				try {
						Connection connection =getConnection();
						Statement stmt= connection.createStatement();
						ResultSet rs=stmt.executeQuery(query);
						while(rs.next()) {
							person ps=new person(rs.getInt("id"),rs.getString("name"),rs.getInt("age"),
									rs.getInt("gender"),rs.getString("job"),rs.getString("position"),rs.getInt("salary"),rs.getString("timework"));
							personl.add(ps);
						}
					} catch (Exception e) {
						// TODO: handle exception
					}
					return personl;
				}
		
}
